const hre = require("hardhat");

async function main() {
  const contractName = process.env.CONTRACT_NAME;

  if (!contractName) {
    console.error("❌ Usage: CONTRACT_NAME=<ContractName> npx hardhat run scripts/deploy.js");
    process.exit(1);
  }

  try {
    const network = hre.network.name;
    const currency = network === 'hardhat' ? 'ETH' : 'AVAX';

    let marketPlaceStatusAddress, marketPlaceSaleAddress;

    const ContractFactory = await hre.ethers.getContractFactory(contractName);
    console.log(`Deploying ${contractName} to ${network} network...`);

    let contract;
    if (contractName === 'MarketPlaceSale') {
      marketPlaceStatusAddress = process.env.MARKETPLACE_STATUS_ADDRESS;
      if (!marketPlaceStatusAddress) {
        throw new Error("MARKETPLACE_STATUS_ADDRESS not set in .env file");
      }
      contract = await ContractFactory.deploy(marketPlaceStatusAddress);
    } else if (contractName === 'MarketPlaceStore') {
      marketPlaceSaleAddress = process.env.MARKETPLACE_SALE_ADDRESS;
      
      if (!marketPlaceSaleAddress) {
        throw new Error("MARKETPLACE_SALE_ADDRESS must be set in .env file");
      }
      
      contract = await ContractFactory.deploy(marketPlaceSaleAddress);
    } else {
      contract = await ContractFactory.deploy();
    }

    const receipt = await contract.deploymentTransaction().wait();

    const gasCost = receipt.gasUsed * receipt.gasPrice;
    const gasCostInCurrency = hre.ethers.formatEther(gasCost);

    console.log(`✅ ${contractName} deployed to:`, contract.target);
    console.log(`💰 Gas used: ${receipt.gasUsed.toString()}`);
    console.log(`💸 Total cost: ${gasCostInCurrency} ${currency}`);

    if (network !== "hardhat") {
      console.log(`🛠️ Verifying contract on SnowTrace...`);
      try {
        await hre.run("verify:verify", {
          address: contract.target,
          constructorArguments: contractName === 'MarketPlaceSale' ? [marketPlaceStatusAddress] :
                               contractName === 'MarketPlaceStore' ? [marketPlaceSaleAddress] :
                               []
        });
        console.log(`✅ Contract verified successfully on SnowTrace!`);
      } catch (error) {
        console.error(`❌ Verification failed: ${error.message}`);
      }
    }

  } catch (error) {
    console.error("❌ Error:", error.message);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});