const hre = require("hardhat");
require('dotenv').config();

async function main() {

    const tokenId = BigInt(process.env.TOKEN_ID);
    if (!process.env.TOKEN_ID) {
        throw new Error("Please provide TOKEN_ID in environment variables");
    }

    console.log(`Approving sale for NFT #${tokenId.toString()}...`);

    const marketPlaceStore = await hre.ethers.getContractAt(
        "MarketPlaceStore",
        process.env.MARKETPLACE_STORE_ADDRESS
    );

    const tx = await marketPlaceStore.approveSale(tokenId);
    await tx.wait();

    console.log(`Sale approved for NFT #${tokenId.toString()}`);
    console.log("Transaction hash:", tx.hash);
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
