const hre = require("hardhat");
require('dotenv').config();

async function main() {
    const tokenId = process.env.TOKEN_ID;
    const price = process.env.PRICE;
    const startDate = process.env.START_DATE;

    if (!tokenId || !price) {
        throw new Error("Missing required environment variables: TOKEN_ID and PRICE must be set");
    }

    const marketPlaceSaleAddress = process.env.MARKETPLACE_SALE_ADDRESS;
    if (!marketPlaceSaleAddress) {
        throw new Error("MARKETPLACE_SALE_ADDRESS not found in environment variables");
    }

    const MarketPlaceSale = await hre.ethers.getContractFactory("MarketPlaceSale");
    const marketPlaceSale = await MarketPlaceSale.attach(marketPlaceSaleAddress);

    const priceInWei = hre.ethers.parseEther(price);
    const startTimestamp = startDate ? Math.floor(new Date(startDate).getTime() / 1000) : 0;

    try {
        const tx = await marketPlaceSale.listNFTSale.staticCall(tokenId, priceInWei, startTimestamp)
            .then(() => marketPlaceSale.listNFTSale(tokenId, priceInWei, startTimestamp));
        await tx.wait();
        
        console.log(`NFT #${tokenId} listed for ${price} AVAX`);
    } catch (error) {
        console.error("Transaction failed:", error.message);
        throw error;
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
