const hre = require("hardhat");
const { ethers } = require("hardhat");
require('dotenv').config();

async function main() {
    // Get parameters from environment variables
    const collection = process.env.COLLECTION;
    const tokenId = process.env.TOKEN_ID;
    const priceInAVAX = process.env.PRICE;
    const startDate = process.env.START_DATE;

    if (!collection || !tokenId || !priceInAVAX) {
        console.error("Missing required environment variables");
        process.exit(1);
    }

    const startTimestamp = startDate ? Math.floor(new Date(startDate).getTime() / 1000) : 0;

    // Convert AVAX to Wei
    const priceInWei = ethers.parseEther(priceInAVAX.toString());

    // Setup contract connections
    const nftCore = await ethers.getContractAt("INFTCore", process.env.NFT_CORE_ADDRESS);
    const marketPlaceStore = await ethers.getContractAt("MarketPlaceStore", process.env.MARKETPLACE_STORE_ADDRESS);

    console.log(`\nInitializing NFT listing process for Token ID: ${tokenId}`);
    console.log(`Collection: ${collection}`);
    console.log(`Price: ${priceInAVAX} AVAX`);
    console.log(`Start Date: ${startTimestamp ? new Date(startTimestamp * 1000).toLocaleString() : 'Immediate'}`);

    try {
        // Check if NFT is already held by MarketPlaceStore.
        const currentOwner = await nftCore.ownerOf(tokenId);
        if (currentOwner.toLowerCase() !== marketPlaceStore.target.toLowerCase()) {
            console.error("\nError: NFT is not held by MarketPlaceStore.");
            console.error("Please manually approve MarketPlaceStore as an operator on NFT Core contract and transfer the NFT to MarketPlaceStore via your wallet.");
            process.exit(1);
        }

        // Propose the sale
        console.log("\nProposing sale...");
        const proposeTx = await marketPlaceStore.proposeSale(tokenId, priceInWei, startTimestamp);
        await proposeTx.wait();
        console.log("Sale proposed successfully!");

        console.log("\nOwner approval is required via wallet interface.");
        console.log(`Expiration time: ${new Date(Date.now() + 3600000).toLocaleString()}`);

    } catch (error) {
        console.error("Error during listing process:", error);
        process.exit(1);
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
