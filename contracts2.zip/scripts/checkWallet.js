const hre = require("hardhat");
const { ethers } = require('ethers');
const { getPrivateKey } = require("../hardhat.config.js");

async function main() {
    // Use the RPC URL from the network configuration
    const provider = new ethers.JsonRpcProvider(hre.network.config.url);
    const wallet = new ethers.Wallet(getPrivateKey(), provider);

    console.log(`✅ Avalanche ${hre.network.name} Address: ${wallet.address}`);

    const balance = await provider.getBalance(wallet.address);
    console.log(`💰 Balance: ${ethers.formatEther(balance)} AVAX`);
}

main().catch((error) => {
    console.error(error);
    process.exit(1);
});
