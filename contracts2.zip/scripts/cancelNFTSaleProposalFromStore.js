const hre = require("hardhat");

async function main() {
    const verbose = process.argv.includes('--verbose');
    const tokenId = process.env.TOKEN_ID;
    const storeAddress = process.env.MARKETPLACE_STORE_ADDRESS;

    if (!tokenId) {
        throw new Error("TOKEN_ID environment variable is required");
    }

    if (!storeAddress) {
        throw new Error("MARKETPLACE_STORE_ADDRESS environment variable is required");
    }

    if (verbose) {
        console.log("Network:", hre.network.name);
        console.log("Token ID:", tokenId);
        console.log("Store Address:", storeAddress);
    }

    const Store = await hre.ethers.getContractFactory("MarketPlaceStore");
    const store = await Store.attach(storeAddress);

    console.log("Cancelling NFT sale proposal...");
    const tx = await store.cancelSaleProposal(tokenId);
    await tx.wait();

    console.log("Sale proposal cancelled successfully!");
    if (verbose) {
        console.log("Transaction:", tx.hash);
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
