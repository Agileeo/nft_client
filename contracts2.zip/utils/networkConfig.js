const getNetworkConfig = (networkName) => {
  if (!networkName) {
    throw new Error("Network name is required (Fuji, Hardhat, or Avalanche)");
  }

  const networks = {
    'Fuji': {
      name: 'fuji',
      currency: 'AVAX'
    },
    'Hardhat': {
      name: 'hardhat',
      currency: 'ETH'
    },
    'Avalanche': {
      name: 'avalanche',
      currency: 'AVAX'
    }
  };

  const network = networks[networkName];
  if (!network) {
    throw new Error("Invalid network. Use Fuji, Hardhat, or Avalanche");
  }

  return network;
};

module.exports = { getNetworkConfig };
